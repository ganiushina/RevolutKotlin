package ru.alta.revolutkotlin

import ru.alta.revolutkotlin.data.entity.Currency

class MainViewState(val currencies: List<Currency>)