package ru.alta.revolutkotlin.data.entity

class Currency (val title: String, val text: String, val color: Int)